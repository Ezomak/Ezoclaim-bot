
const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const fs = require("fs");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(__dirname));

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"));
});

app.get("/claim", (req, res) => {
    res.sendFile(path.join(__dirname, "claim.html"));
});

app.post("/claim", (req, res) => {
    const { telegramId } = req.body;
    const log = `Claim from: ${telegramId} at ${new Date().toISOString()}
`;
    fs.appendFileSync("claims.log", log);
    res.send(`<p>Thank you! Claim received for Telegram ID: ${telegramId}</p><a href='/'>Back</a>`);
});

app.get("/admin", (req, res) => {
    const logs = fs.existsSync("claims.log") ? fs.readFileSync("claims.log", "utf8") : "No claims yet.";
    res.send(`<pre>${logs}</pre><a href='/'>Back</a>`);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server started on port " + PORT));
